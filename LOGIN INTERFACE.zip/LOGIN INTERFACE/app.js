// Show the Sign-Up form
function showSignUp() {
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('signUpForm').style.display = 'block';
  }
  
  // Show the Login form
  function showLogin() {
    document.getElementById('signUpForm').style.display = 'none';
    document.getElementById('loginForm').style.display = 'block';
  }
  
  // Sign-Up functionality
  document.getElementById('signUpForm').addEventListener('submit', function(event) {
    event.preventDefault();
  
    const username = document.getElementById('signupUsername').value;
    const password = document.getElementById('signupPassword').value;
  
    if (username && password) {
      // Save user data to localStorage
      const users = JSON.parse(localStorage.getItem('users')) || [];
      users.push({ username, password });
      localStorage.setItem('users', JSON.stringify(users));
      alert('Account created successfully!');
      showLogin();
    } else {
      alert('Please fill out both fields');
    }
  });
  
  // Login functionality
  document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
  
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;
  
    if (username && password) {
      const users = JSON.parse(localStorage.getItem('users')) || [];
      const user = users.find(u => u.username === username && u.password === password);
  
      if (user) {
        alert('Login successful!');
        // Redirect to another page or dashboard
      } else {
        alert('Invalid credentials. Please try again.');
      }
    } else {
      alert('Please fill out both fields');
    }
  });
  